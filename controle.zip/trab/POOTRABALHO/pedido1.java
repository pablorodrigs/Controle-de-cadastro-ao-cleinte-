import java.util.Scanner;



public class pedido1 {

    Scanner ler = new Scanner(System.in);
    int indentificador = 27;
    int valor = 200;
   
		
    
    
    
}
