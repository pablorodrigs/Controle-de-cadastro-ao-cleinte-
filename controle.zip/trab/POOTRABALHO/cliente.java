import java.util.Scanner;
import java.text.ParseException;
import java.util.Date;
public class cliente {
    public static void main(String[] args) {

        
        System.out.println("*****Menu*****");
        System.out.println("<1> Cadastrar Cliente");
        System.out.println("<2> Cadastrar Fornecedor");
        System.out.println("<6> Sair");
        Scanner ler = new Scanner(System.in);
        String opEscolhida = ler.nextLine();
        String nomedoFornecedor = null;

        do{
            switch(opEscolhida){
                case "1": System.out.println("Informacoes dobre o cliente!\n");
                        System.out.println("Qual é o nome do cliente?");
                        String nome = ler.next();
                        System.out.println("Qual é o email do cliente?");
                        String Email = ler.next();
                        System.out.println("Qual é o cpf do cliente?");
                        String cpf = ler.next();
                        System.out.println("Em quantas vezes será parcelado?");
                        int parcelamento = ler.nextInt();
                        System.out.println("O cliente é uma pessoa juridica?");
                        String Juridica = ler.next();
                        String sim = ler.next();
                        
                        if(sim.equals("sim")) 
                        {
                         System.out.println("Digite o cnpj");
                         String cnpj = ler.next();
                         System.out.println("Informações do cliente\nnome:"+ nome + "\nEmail:"+ Email + "\ncpf:" + cpf + "\nparcelamento:" + parcelamento + "\ncnpj:"+cnpj);
                        
                        
                        }
                        else
                        {
                            System.out.println("Informações do cliente\nnome:"+ nome + "\nEmail:"+ Email + "\ncpf:" + cpf + "\nparcelamento:" + parcelamento);
                        }
                        break;
                case "2": System.out.println("Preencha as informações do fornecedor\n");
                        System.out.println("Qual é o nome do fornecedor?");
                        nomedoFornecedor = ler.next();
                        System.out.println("Qual o CNPJ do fornecedor?");
                        int cnpjdoFornecedor = ler.nextInt();
                        System.out.println("Qual o produto do fornecedor?");
                        String produto = ler.next();
                        System.out.println("Dados do fornecedor\nnome:" + nomedoFornecedor + "\ncnpj:" + cnpjdoFornecedor+ "\nproduto" + produto + "\n" );
                        System.out.println(" Informações do pedido");
                        break;
                case "3": System.out.println("Finalizando programa");
            
            int indentificador ;
            int valor;
            indentificador = 27;
            valor = 5000;
            int AA;
           

            System.out.println("Forma de pagamento");

            System.out.println("Dinheiro ou cartao");
            int dinheiro = ler.nextInt();
            int cartao = ler.nextInt();

           if(dinheiro == valor)
           {
           System.out.println("Sera pago avista o valor de" +valor);
           }
           else{

             System.out.println("Quantas vezes sera parcelado"); ;
            int parcela = ler.nextInt();

            AA= valor / parcela;
             
            System.out.println("o valor da parcela sera "+AA +"por mes");

           }


                
                
            System.out.println("número de indentificação:" + indentificador);
            System.out.println("Nome do fornecedor:" + nomedoFornecedor);
            System.out.println("Valor total do produto é de:"  + valor);
            Date data = new Date();
            System.out.println("Data da realização do pedido "+data);
            }
        }while(!opEscolhida.equals("6"));
        ler.close();
    }
}
    

