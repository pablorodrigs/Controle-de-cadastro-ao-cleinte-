import java.util.Scanner;

public class fornecedor {

    Scanner ler = new Scanner(System.in);

    String nomedoFornecedor = ler.next();
    String produto = ler.next();
    int cnpjdoFornecedor = ler.nextInt();


    
}
