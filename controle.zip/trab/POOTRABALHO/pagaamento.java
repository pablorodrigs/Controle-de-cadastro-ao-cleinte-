import java.util.Scanner;
public class pagaamento{

    Scanner ler = new Scanner(System.in);
    int dinheiro = ler.nextInt();
    int cartao = ler.nextInt();
    int parcrla = ler.nextInt();



}