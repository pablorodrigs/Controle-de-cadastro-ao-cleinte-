import java.util.Scanner;

public class Cadastro {
    Scanner ler = new Scanner(System.in);

    String nome = ler.next();
    String Email = ler.next();
    int cpf = ler.nextInt();
    String Juridica = ler.next();
    int cnpj = ler.nextInt();
    String sim = ler.next();
}
